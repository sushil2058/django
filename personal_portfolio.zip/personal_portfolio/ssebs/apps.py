from django.apps import AppConfig


class SsebsConfig(AppConfig):
    name = 'ssebs'
